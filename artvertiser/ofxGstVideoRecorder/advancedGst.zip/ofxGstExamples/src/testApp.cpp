#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofSetVerticalSync(true);

	// advanced gstreamer examples
	// ofGstUtils doesn't include a texture so
	// you'll need to use your own

	// getting part of the screen as pixels
	//gst.setPipeline("ximagesrc do-timestamp=true startx=0 starty=0 endx=640 endy=480 use-damage=false ! video/x-raw-rgb, framerate=30/1, depth=24 ! ffmpegcolorspace ",3,false,640,480);

	// getting jpeg streams from axis cameras
	//gst.setPipeline("souphttpsrc location=http://165.91.110.101:2010/axis-cgi/mjpg/video.cgi?showlength=1 do-timestamp=true ! multipartdemux ! image/jpeg ! jpegdec ! ffmpegcolorspace ",3,false);
	//gst.setPipeline("souphttpsrc location=http://62.128.241.214:88/axis-cgi/mjpg/video.swf?resolution=640x480&camera=1 do-timestamp=true ! decodebin ! ffmpegcolorspace ",3,false,640,480);

	// receiving jpeg udp stream from gstreamer udp server like ofxGstVideoRecorder
	//gst.setPipeline("udpsrc port=4444 caps=\"application/x-rtp, media=video, clock-rate=90000\" ! queue ! rtpjpegdepay ! decodebin ! ffmpegcolorspace");

	// receiving jpeg udp stream from gstreamer udp server like ofxGstVideoRecorder
	//gst.setPipeline("udpsrc port=4444 caps=\"application/x-rtp, media=video, clock-rate=90000\" ! queue ! rtptheoradepay ! video/x-theora, width=640, height=480 ! decodebin ! ffmpegcolorspace");

	// receiving mp4 udp stream from gstreamer udp server like ofxGstVideoRecorder
	//gst.setPipeline("udpsrc port=4444 caps=\"application/x-rtp, media=video, clock-rate=90000\" ! rtpmp4vdepay ! decodebin ! ffmpegcolorspace");

	// receiving h264 udp stream from gstreamer udp server like ofxGstVideoRecorder
	//gst.setPipeline("udpsrc port=4444 caps=\"application/x-rtp, media=video, clock-rate=90000\" ! rtph264depay ! decodebin ! ffmpegcolorspace");

	// receiving tcp stream with any codec from gstreamer tcp server like ofxGstVideoRecorder
	gst.setPipeline("tcpclientsrc port=4444 host=localhost ! mpegtsdemux ! decodebin ! ffmpegcolorspace");

	gst.play();
	tex.allocate(gst.getWidth(),gst.getHeight(),GL_RGB);

}

//--------------------------------------------------------------
void testApp::update(){
	gst.update();
	if(gst.isFrameNew()) tex.loadData(gst.getPixels(),640,480,GL_RGB);
}

//--------------------------------------------------------------
void testApp::draw(){
	ofSetColor(255,255,255);
	tex.draw(0,0);
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}


//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::resized(int w, int h){

}
