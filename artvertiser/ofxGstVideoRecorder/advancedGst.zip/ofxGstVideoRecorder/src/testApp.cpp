#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
	ofSetVerticalSync(true);
	grabber.initGrabber(640,480,true);

	// streaming to tcp client needs setup to specify what to send
	//recorder.tcpStreamTo("127.0.0.1",4444);

	// streaming to udp client needs setup to specify what to send
	// with udp you can specify several clients to send to
	// separated by commas
	//recorder.udpStreamTo("127.0.0.1:4444");

	// for passing info in update using newFrame(pixels)
	//recorder.setup(640,480,24,"movie.mpg",ofxGstVideoRecorder::H264);

	// records an ofBaseImage or ofBaseVideo
	recorder.setup(grabber,24,"movie.avi",ofxGstVideoRecorder::H264);

	// records part of the window
	//recorder.setupRecordWindow(0,0,640,480,24,"screenshot.mpg",ofxGstVideoRecorder::H264,30);

	// records part of the screen
	//recorder.setupRecordScreen(0,0,640,480,24,"screenshot.mpg",ofxGstVideoRecorder::H264);


}

//--------------------------------------------------------------
void testApp::update(){
	//record any pixels info
	//img.grabScreen(20,20,640,480);
	//recorder.newFrame(img.getPixels());

	grabber.update();
}

//--------------------------------------------------------------
void testApp::draw(){
	ofSetColor(255,255,255);
	ofCircle(ofGetFrameNum()%640,ofGetElapsedTimeMillis()/10%480,10);
	ofDrawBitmapString(ofToString(ofGetFrameRate(),2),20,40);
}

//--------------------------------------------------------------
void testApp::keyPressed  (int key){

}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){
}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}


//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){
}

//--------------------------------------------------------------
void testApp::resized(int w, int h){

}
